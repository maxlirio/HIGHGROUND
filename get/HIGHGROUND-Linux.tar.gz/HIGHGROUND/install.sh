#!/bin/sh
# Installs HIGHGROUND for this user (no root needed): the launcher, an app-menu entry and the icon.
set -e
cd "$(dirname "$0")"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/256x256/apps"
cp highground "$HOME/.local/bin/highground" && chmod +x "$HOME/.local/bin/highground"
cp icon.png "$HOME/.local/share/icons/hicolor/256x256/apps/highground.png"
cat > "$HOME/.local/share/applications/highground.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=HIGHGROUND
Comment=The Realm — the family kingdom
Exec=$HOME/.local/bin/highground
Icon=highground
Terminal=false
Categories=Game;StrategyGame;
DESK
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" || true
echo "Installed. Find HIGHGROUND in your app menu (log out/in if it doesn't appear), or run: highground"
echo "To remove: rm ~/.local/bin/highground ~/.local/share/applications/highground.desktop ~/.local/share/icons/hicolor/256x256/apps/highground.png"
